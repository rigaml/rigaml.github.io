# SnapTimer for Windows

SnapTimer is a compact countdown timer and stopwatch for Windows 10 and 11. This project is a Python port of Dan Hersam’s [original SnapTimer 0.2 for Lazarus](https://github.com/jaden/SnapTimer).

## Run SnapTimer

Extract the Windows release ZIP and open **SnapTimer.exe** from File Explorer, or build the executable using the instructions below. The portable x86 executable bundles Python, Tk, icons, alarm sounds, and countdown music. It targets standard Windows desktop PCs with x86, x64, or ARM64 processors. Windows on ARM runs it through its built-in x86 emulation. Use a regular Windows desktop session with Explorer for the notification area features.

To run from source, install [Python for Windows](https://www.python.org/downloads/windows/) with Tcl/Tk. Python 3.15 is recommended. The app also runs from source on Python 3.11 and later. Double-click **SnapTimer.pyw** or run:

    python -m snaptimer

The source has no third-party runtime dependencies. Both launchers accept a duration in the configured units. Omit it to use the saved duration.

    .\dist\SnapTimer.exe 20 --start
    python -m snaptimer 0
    python -m snaptimer 5 --ini .\break.ini

## Use the timer

- Enter 0 for a stopwatch or 1–5999 for a countdown. Use **Up** and **Down** to change the value by five. Set seconds mode in **Edit → Options → General** to enter seconds.
- Press **Enter** to start or pause. Click the time to start or pause and double-click to reset. **Ctrl+R** also resets. **Esc** closes the app.
- Enable **Show elapsed time** in **Edit → Options → General** to see a smaller clock to the right of the countdown. It counts from the first Start through pauses and automatic restarts. Stop/Reset freezes that total and the next Start begins at zero.
- Enable **Restart the countdown after the alarm** in **Edit → Options → General** to show the restart fraction beside the duration. Choose **None** to repeat the original duration, pick **1/2**, **1/3**, **1/4**, or **1/5**, or enter a decimal greater than 0 and at most 1. Press **Enter** or leave the field to apply it. Each shortened restart uses that fraction of the previous duration, rounded down to a whole second with a one-minute minimum. Reset returns to the starting duration.
- Use **Edit → Options** to select message, Windows notification, WAV, and program/file alarms. Use **Test** beside each alarm to try it immediately. Windows controls where notification icons appear and can suppress notification pop-ups when Do Not Disturb is on.
- **Play music during the countdown** is enabled by default in **Edit → Options → Alarms**. SnapTimer plays the bundled tracks in numeric order. Each countdown gets one looping track, and the playlist wraps after the last track. Pause holds the track at its current position, and Reset returns to the first track. An automatic restart with music waits for the WAV alarm before starting the next countdown. Without a message box to dismiss, that alarm plays once. When running from source, place any additional numbered MP3 or WAV files in `snaptimer/assets/music`.
- Right-click the notification icon to see the time and controls. Click it to restore a window minimized to the notification area or to pause or resume a visible timer.
- Moving the pointer out of the timer window switches to compact mode and keeps the clock at the size you set by resizing the window. Move the pointer back over the clock to restore the controls. Use **Ctrl+M** or right-click the time to switch modes manually.
- Resize the window to change the clock text size. Set the font family, style, and colors in **Edit → Options → Appearance**.

Settings are saved automatically by default to **%LOCALAPPDATA%\SnapTimer\snaptimer.ini**. The first-run defaults keep the window on top, remember its position, show elapsed time, and restart the countdown after playing `alarm_03.wav`. The clock uses bold red Arial on a black background. For a portable setup, launch once with **--portable** from a writable folder. Subsequent launches use the INI beside the executable when it exists. You can also copy in an existing SnapTimer INI or use **--ini PATH** to give an instance its own settings. Relative alarm paths are first resolved beside the INI, then beside the executable or source launcher, and then against the bundled assets.

## Project structure

| Module | Responsibility |
| --- | --- |
| timer.py | Countdown and stopwatch state. Fractional time survives pause and resume, and expiration fires once. |
| settings.py | Original INI keys, defaults, path resolution, and atomic writes. |
| app.py, options.py | Main timer window, commands, and three-tab options dialog. |
| windows.py, alerts.py | Native notification icon, window placement, WAV playback, and opening configured files. |

The port fixes the original countdown’s off-by-one display, applies appearance changes without resetting an active timer, and restores the controls when exiting compact mode.

## Verify and build

Run the behavioral and INI tests from a PowerShell prompt at the project root:

    python -B -m unittest discover -s tests -v

On an interactive Windows desktop with an audio device and Explorer, enable the desktop integration checks before running the same suite:

    $env:SNAPTIMER_GUI_TESTS = '1'
    python -B -m unittest discover -s tests -v

To reproduce the portable x86 build, run the following with a **32-bit** installation of Python with Tcl/Tk. Use an interpreter matching the desired architecture to build a native x64 or ARM64 version.

    python -m venv .build-env
    .\.build-env\Scripts\python.exe -m pip install -r requirements-build.txt
    .\.build-env\Scripts\python.exe build.py

The build writes **dist/SnapTimer.exe** and includes numbered MP3 and WAV files present in `snaptimer/assets/music`. To create **dist/SnapTimer-Windows.zip** for distribution, make FFmpeg available on PATH and run:

    .\.build-env\Scripts\python.exe build.py --release

You can pass the path to FFmpeg after `--release`. The ZIP contains the executable, this README, and `MUSIC-CREDITS.md`. The release stores any MP3 tracks in WAV containers so Windows can play them through its waveform audio driver. The audio is copied without re-encoding.

## Attribution

The original [SnapTimer](https://github.com/jaden/SnapTimer) was written by Dan Hersam and described as freeware in the original readme. The bundled sounds and icons come from the supplied source. The original project credits [Freesound](https://freesound.org/), A1 Free Sound Effects, and FatCow's icon collection.

Countdown recording credits and licenses are listed in `MUSIC-CREDITS.md` in the Windows ZIP and in `snaptimer/assets/music/ATTRIBUTION.md` in the source folder.

## Changelog

### 2026-11-26

- Updated the first-run Options defaults, including bold red Arial on black, and bundled countdown music with credits in the Windows release.

### 2026-11-24

- Fixed compact mode shrinking the clock text after resizing the window.
- Published the Python port in a standalone GitHub repository with credit to Dan Hersam. The countdown music and locally built executable were kept out of the repository.

### 2026-11-23

- Added an optional elapsed-time clock beside the countdown in both window modes. It counts through pauses and automatic restarts, freezes on Stop/Reset, and starts at zero on the next fresh Start.
- Added optional countdown music from numbered MP3 or WAV files. One track loops per interval, playback resumes from the paused position, and automatic restarts wait for the WAV alarm before moving to the next track.
- Added preset and custom restart fractions to shorten each successive countdown, with a one-minute minimum. Reset restores the original duration.
- Made the clock text scale with the window in both modes and kept the title bar draggable and the minimize button accessible at small sizes.
- Moved the controls to the right and added automatic compact mode when the pointer leaves the window. Moving back over the clock restores the controls and previous window size.
- Reduced the default and minimum window sizes, tightened clock padding.

### 2026-11-20

- Completed the initial Python port for Windows 10 and 11, preserving the countdown, stopwatch, tray controls, alarms, and compatibility with existing SnapTimer INI settings.
